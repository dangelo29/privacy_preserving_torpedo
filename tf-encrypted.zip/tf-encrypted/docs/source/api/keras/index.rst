Keras
======

.. automodule:: tf_encrypted.keras
    :members:

.. toctree::
    :glob:

    ../../gen/tf_encrypted.keras.layers*
    ../../gen/tf_encrypted.keras.models*
