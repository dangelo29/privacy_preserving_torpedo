# Research

This folder contains code to reproduce results from research papers. Currently,
the following papers are included: 

* Semi-supervised Knowledge Transfer for Deep Learning from Private Training
  Data (ICLR 2017): `pate_2017`

* Scalable Private Learning with PATE (ICLR 2018): `pate_2018`
