Bloom's method
==================================
TODO
