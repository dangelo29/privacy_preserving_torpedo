# Overview

Various examples related to [*SecureNN: Efficient and Private Neural Network Training*](https://eprint.iacr.org/2018/442).
